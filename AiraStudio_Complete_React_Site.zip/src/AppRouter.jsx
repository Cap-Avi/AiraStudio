import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ClothingStore from './Home';
import LoadingSpinner from './components/LoadingSpinner';
export default function AppRouter() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<ClothingStore />} />
        <Route path='/loading' element={<LoadingSpinner />} />
        {/* Add more routes here */}
      </Routes>
    </Router>
  );
}