import { motion } from 'framer-motion';
export default function LoadingSpinner() {
  return (
    <div className='flex items-center justify-center h-screen'>
      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}>
        <img src='/images/dress-loading.png' alt='loading' className='w-64 h-64' />
      </motion.div>
    </div>
  );
}